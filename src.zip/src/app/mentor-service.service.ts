import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Mentor } from './mentor';

@Injectable({
  providedIn: 'root'
})
export class MentorServiceService {
  private baseUrl = 'http://localhost:9531/api';


  constructor(private http: HttpClient) { }
  CreateMentor(Mentor: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/mentorcreate`, Mentor);
  }
  searchUser(username: string,password :string): Observable<any> {
    console.log(username)
    return this.http.get(`${this.baseUrl}/login/${username}/${password}`);
  }

}
