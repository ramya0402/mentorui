import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-training-progress',
  templateUrl: './mentor-training-progress.component.html',
  styleUrls: ['./mentor-training-progress.component.css']
})
export class MentorTrainingProgressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
