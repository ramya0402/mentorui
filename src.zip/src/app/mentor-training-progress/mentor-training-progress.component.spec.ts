import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorTrainingProgressComponent } from './mentor-training-progress.component';

describe('MentorTrainingProgressComponent', () => {
  let component: MentorTrainingProgressComponent;
  let fixture: ComponentFixture<MentorTrainingProgressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorTrainingProgressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorTrainingProgressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
