import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserTrainingCompletedComponent } from './user-training-completed.component';

describe('UserTrainingCompletedComponent', () => {
  let component: UserTrainingCompletedComponent;
  let fixture: ComponentFixture<UserTrainingCompletedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserTrainingCompletedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserTrainingCompletedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
