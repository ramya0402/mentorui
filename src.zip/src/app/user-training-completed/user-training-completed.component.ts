import { Component, OnInit } from '@angular/core';
//import 'src\app\JavaScript\UserTrainingCompleted.js';

@Component({
  selector: 'app-user-training-completed',
  templateUrl: './user-training-completed.component.html',
  styleUrls: ['./user-training-completed.component.css']
})
export class UserTrainingCompletedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
