import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { RouterModule } from '@angular/router';
import { MentorSigninComponent } from './mentor-signin/mentor-signin.component';

import { MentorMenuComponent } from './mentor-menu/mentor-menu.component';
import { MentorPaymentComponent } from './mentor-payment/mentor-payment.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import { MentorTrainingCompletedComponent } from './mentor-training-completed/mentor-training-completed.component';
import { MentorTrainingProgressComponent } from './mentor-training-progress/mentor-training-progress.component';
import { ProfileViewComponent } from './profile-view/profile-view.component';
import { UserMenuComponent } from './user-menu/user-menu.component';
import { UserPaymentComponent } from './user-payment/user-payment.component';
import { UserSearchResultsComponent } from './user-search-results/user-search-results.component';
import { UserSigninComponent } from './user-signin/user-signin.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { UserTrainingCompletedComponent } from './user-training-completed/user-training-completed.component';
import { UserTrainingProgressComponent } from './user-training-progress/user-training-progress.component';
import { MentorEditSkillsComponent } from './mentor-edit-skills/mentor-edit-skills.component';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    AppComponent,
    MentorSignupComponent,
    MentorSigninComponent,
    MentorMenuComponent,
    MentorPaymentComponent,
    MentorProfileComponent,
    MentorTrainingCompletedComponent,
    MentorTrainingProgressComponent,
    ProfileViewComponent,
    UserMenuComponent,
    UserPaymentComponent,
    UserSearchResultsComponent,
    UserSigninComponent,
    UserSignupComponent,
    UserTrainingCompletedComponent,
    UserTrainingProgressComponent,
    MentorEditSkillsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
