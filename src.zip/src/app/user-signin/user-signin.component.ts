import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserServiceService } from '../user-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-signin',
  templateUrl: './user-signin.component.html',
  styleUrls: ['./user-signin.component.css']
})
export class UserSigninComponent implements OnInit {
  user1: User
  password:string;
  username:string
  constructor(private userService: UserServiceService,private router:Router) { }

  ngOnInit() {
  }
  onSubmit() {
    
    console.log("save")
    this.userService.searchUser(this.username,this.password).subscribe(
      (user:User)=>{
        console.log(user)
        if(user!=null)
        {
          this.createUser(user)
          this.router.navigate(['usermenu']);
        }
      else{
        this.router.navigate(['usersignin']);
      } 
      }
    
    );
     
    
  }

  createUser(user: User){
    this.user1=user
    window.localStorage.setItem("user",this.user1.username);
    
  }
}
