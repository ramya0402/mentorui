import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-menu',
  templateUrl: './mentor-menu.component.html',
  styleUrls: ['./mentor-menu.component.css']
})
export class MentorMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
