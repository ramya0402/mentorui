import { NgModule } from '@angular/core';
import { RouterModule,Routes } from '@angular/router';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { MentorTrainingCompletedComponent } from './mentor-training-completed/mentor-training-completed.component';
import { MentorTrainingProgressComponent } from './mentor-training-progress/mentor-training-progress.component';
import { MentorPaymentComponent } from './mentor-payment/mentor-payment.component';
import { MentorEditSkillsComponent } from './mentor-edit-skills/mentor-edit-skills.component';
import { MentorMenuComponent } from './mentor-menu/mentor-menu.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import { MentorSigninComponent } from './mentor-signin/mentor-signin.component';
import { UserSigninComponent } from './user-signin/user-signin.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { UserMenuComponent } from './user-menu/user-menu.component';
import { ProfileViewComponent } from './profile-view/profile-view.component';
import { UserPaymentComponent } from './user-payment/user-payment.component';
import { UserTrainingProgressComponent } from './user-training-progress/user-training-progress.component';
import { UserTrainingCompletedComponent } from './user-training-completed/user-training-completed.component';

const routes: Routes = [
  {path:'',component:MentorSignupComponent},
      {path:'mentortrainingcompleted',component:MentorTrainingCompletedComponent},
      {path:'mentortrainingprogress',component:MentorTrainingProgressComponent},
      {path:'mentorpayment',component:MentorPaymentComponent},
      {path:'mentoreditskills',component:MentorEditSkillsComponent},
      {path:'mentormenu',component:MentorMenuComponent},
      {path:'mentorprofile',component:MentorProfileComponent},
      {path:'mentorsignin',component:MentorSigninComponent},
      {path:'usersignin',component:UserSigninComponent},
      {path:'usersignup',component:UserSignupComponent},
      {path:'usermenu',component:UserMenuComponent},
      {path:'profileview',component:ProfileViewComponent},
      {path:'userpayment',component:UserPaymentComponent},
      {path:'usertrainingprogress',component:UserTrainingProgressComponent},
      {path:'usertrainingcompleted',component:UserTrainingCompletedComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
