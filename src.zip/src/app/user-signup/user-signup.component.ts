import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserServiceService } from '../user-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-signup',
  templateUrl: './user-signup.component.html',
  styleUrls: ['./user-signup.component.css']
})
export class UserSignupComponent implements OnInit {
  user: User = new User();
  submitted = false;

  constructor(private userService:UserServiceService, private router: Router) { }

  ngOnInit() {
  }
  newMentor(): void {
    this.submitted = false;
    this.user = new User();
    
   
  }

  save() {
    this.userService.CreateUser(this.user)
      .subscribe(data => console.log(data), error => console.log(error));
    this.user = new User();
    
    
  }
  onSubmit() {
    this.submitted = true;
    this.save();
    this.router.navigate(['usersignin']);
    
  }


}
