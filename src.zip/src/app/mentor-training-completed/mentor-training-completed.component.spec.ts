import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorTrainingCompletedComponent } from './mentor-training-completed.component';

describe('MentorTrainingCompletedComponent', () => {
  let component: MentorTrainingCompletedComponent;
  let fixture: ComponentFixture<MentorTrainingCompletedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorTrainingCompletedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorTrainingCompletedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
