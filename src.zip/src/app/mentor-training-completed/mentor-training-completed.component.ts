import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-training-completed',
  templateUrl: './mentor-training-completed.component.html',
  styleUrls: ['./mentor-training-completed.component.css']
})
export class MentorTrainingCompletedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
