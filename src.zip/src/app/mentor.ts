export class Mentor {
    id: number;
    username: string;
    linkedin_url:string;
    reg_datetime:Date;
    years_of_experience:number;
    technology:string;
    contact_num:Number;
    email:String;
    work_timings:string;
    password:string;
}
