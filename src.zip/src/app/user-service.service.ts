import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  private baseUrl = 'http://localhost:9531/api';

  constructor(private http:HttpClient) { }
  CreateUser(User: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/usercreate`, User);
  }
  searchUser(username: string,password :string): Observable<any> {
    console.log(username)
    return this.http.get(`${this.baseUrl}/userlogin/${username}/${password}`);
  }
}
