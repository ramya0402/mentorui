import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserTrainingProgressComponent } from './user-training-progress.component';

describe('UserTrainingProgressComponent', () => {
  let component: UserTrainingProgressComponent;
  let fixture: ComponentFixture<UserTrainingProgressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserTrainingProgressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserTrainingProgressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
