import { Component, OnInit } from '@angular/core';
//import 'src\app\JavaScript\UserTrainingProgress.js';

@Component({
  selector: 'app-user-training-progress',
  templateUrl: './user-training-progress.component.html',
  styleUrls: ['./user-training-progress.component.css']
})
export class UserTrainingProgressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
