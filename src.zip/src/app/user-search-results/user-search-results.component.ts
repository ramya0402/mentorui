import { Component, OnInit } from '@angular/core';
//import 'src\app\JavaScript\UserSearch.js';

@Component({
  selector: 'app-user-search-results',
  templateUrl: './user-search-results.component.html',
  styleUrls: ['./user-search-results.component.css']
})
export class UserSearchResultsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
