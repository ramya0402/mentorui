import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Mentor } from '../mentor';
import { MentorServiceService } from '../mentor-service.service';

@Component({
  selector: 'app-mentor-signin',
  templateUrl: './mentor-signin.component.html',
  styleUrls: ['./mentor-signin.component.css']
})
export class MentorSigninComponent implements OnInit {
  mentor1: Mentor
  password:string;
  username:string

  constructor(private mentorService: MentorServiceService,private router:Router) { }

  ngOnInit() {
    
  }
  onSubmit() {
    
    console.log("save")
    this.mentorService.searchUser(this.username,this.password).subscribe(
      (mentor:Mentor)=>{
        console.log(mentor)
        if(mentor!=null)
        {
          this.createUser(mentor)
          this.router.navigate(['mentormenu']);
        }
      else{
        this.router.navigate(['mentorsignin']);
      } 
      }
    
    );
     
    
  }

  createUser(mentor: Mentor){
    this.mentor1=mentor
    window.localStorage.setItem("mentor",this.mentor1.username);
    
  }
}


